package com.example.My;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Myboot3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
